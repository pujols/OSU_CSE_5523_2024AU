python3 dnn_mlp_nononlinear.py
