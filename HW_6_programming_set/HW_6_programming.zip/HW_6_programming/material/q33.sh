python3 dnn_mlp.py
